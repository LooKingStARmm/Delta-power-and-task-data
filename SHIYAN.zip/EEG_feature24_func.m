function [feature_all,features_table2] = EEG_feature24_func(eeg_data,Delta1,Theta1,Alpha1,Beta1,Gamma1,start_times,end_times,class)
%eeg_data:输入的信号，start_times,end_times：起始时间点和终止时间点，class:对应数据组的标签
%num：两个实验的序号,其数量应该与时间段个数一样
% start_times = [0, 22, 46, 74, 111, 135, 147, 170, 180, 195, 248, 263, 300];
% end_times = [22, 46, 74, 111, 135, 147, 170, 180, 195, 248, 263, 300, 350];
% class=[1 1 1 1 1 1 1 1 1 1 1 1 1];
% 采样率（Hz）
sampling_rate = 512; % 假设采样率为512Hz 
% eeg_data=rawdata1;
for i = 1:length(start_times)
    num=i;
    % 获取对应时间点的数据样本
    start_sample = start_times(i) * sampling_rate + 1;
    end_sample = end_times(i) * sampling_rate + 1;
    data = eeg_data(start_sample:end_sample);
    data_Delta=Delta1(start_sample:end_sample);
    data_Theta=Theta1(start_sample:end_sample);
    data_Alpha=Alpha1(start_sample:end_sample);
    data_Beta=Beta1(start_sample:end_sample);
    data_Gamma=Gamma1(start_sample:end_sample);
    sumfc1=0;
     sumfc2=0;
     sum3=0;
     sum4=0;
     N = length(data);
    for j=2:length(data)
        fc1=data(j-1)*(data(j)+data(j-1))/2;
        sumfc1=sumfc1+fc1;
        fc2=(data(j)+data(j-1))/2;
        sumfc2=sumfc2+fc2;
        fc3=data(j-1)^2*(data(j)+data(j-1))/2;
        sum3=sum3+fc3;
    end
    for k=1:length(data)
        sum4=sum4+data(k);
    end
    FC=sumfc1./sumfc2;%重心

    % 计算信号特征
    max_val = max(data);%最大值
    min_val = min(data);%最小值
    mean_val = mean(data);%平均值
    std_val = std(data);%标准差
    rms_val = rms(data);%均方根值
%     [R, lag] = autocorr(data);%自回归系数R
%     ar_coef = polyfit(segment(1:end-1), segment(2:end), 1);

% 计算Renyi值（其中alpha的值可以按需更改）
alpha = 2;
renyi = 1/(1-alpha) * log2(sum(data.^alpha));

% 计算Renyi熵
renyi_entropy = 1/(1-alpha) * log2(sum(data.^alpha))/length(data);

% 计算对数能量熵
log_energy_entropy = sum(data.^2 .* log2(data.^2))/sum(data.^2);

% 计算Shannon熵
p = histcounts(data, 'Normalization', 'probability'); % 求概率密度函数
shannon_entropy = -sum(p.*log2(p));

% 计算Tsallis熵（其中q的值可以按需更改）
q = 2;
tsallis_entropy = 1/(q-1) * (1-sum(data.^q))/length(data);

% 计算时变对数方根
log_root_mean_square = sqrt(sum(log(data).^2)/length(data));

% 计算Teager平均能量
teager_energy = sum(abs(data(2:end-1)).^2 - data(1:end-2).*data(3:end))/length(data);
%{
% 计算归一化二阶差均值:是个多元素矩阵
norm_2nd_diff = diff(segment, 2)./segment(2:end-1);

% 计算二阶差
second_diff = diff(segment, 2);

% 计算归一化一阶差
norm_1st_diff = diff(segment)./segment(2:end);

% 计算一阶差
first_diff = diff(segment);
%}
% 计算峰度
kurtosis = sum((data - mean(data)).^4)/(length(data)*std(data)^4) - 3;

% 计算偏度
skewness = sum((data - mean(data)).^3)/(length(data)*std(data)^3);

% 计算Hjorth复杂性
activity = var(data);
mobility = sqrt(var(diff(data)));
complexity = mobility/activity;

% 计算Hjorth移动性
hjorth_mobility = sqrt(var(diff(data)))/sqrt(var(data));

% 计算Hjorth活动性
hjorth_activity = var(data)/sqrt(var(diff(data)));
%% 获得能量占比
nfft = 2^nextpow2(length(data)); % the number of FFT points
% check the help file to learn how to specify parameters in "peridogram.m"
[P_per1, f] = periodogram( detrend(data_Delta),[],nfft,sampling_rate); 
[P_per2, f] = periodogram( detrend(data_Theta),[],nfft,sampling_rate); 
[P_per3, f] = periodogram( detrend(data_Alpha),[],nfft,sampling_rate); 
[P_per4, f] = periodogram( detrend(data_Beta),[],nfft,sampling_rate); 
[P_per5, f] = periodogram( detrend(data_Gamma),[],nfft,sampling_rate); 
[P_per6, f] = periodogram( detrend(data),[],nfft,sampling_rate); 
ZB_DE=sum(P_per1)/sum(P_per6);%五种波形的能量占比
ZB_TH=sum(P_per2)/sum(P_per6);
ZB_AL=sum(P_per3)/sum(P_per6);
ZB_BE=sum(P_per4)/sum(P_per6);
ZB_GA=sum(P_per5)/sum(P_per6);
% 计算各波段的平均功率谱密度
[Pxx, freqs] = pwelch(data,[],[],[],sampling_rate);
delta_freq_range = freqs >= 0.5 & freqs < 4; % delta波频率带范围
theta_freq_range = freqs >= 4 & freqs < 8;  % theta波频率带范围
alpha_freq_range = freqs >= 8 & freqs < 13; % alpha波频率带范围
beta_freq_range = freqs >= 13 & freqs < 30; % beta波频率带范围
gamma_freq_range = freqs >= 30 & freqs < 100; % gamma波频率带范围

delta_avg_power = mean(Pxx(delta_freq_range));
theta_avg_power = mean(Pxx(theta_freq_range));
alpha_avg_power = mean(Pxx(alpha_freq_range));
beta_avg_power = mean(Pxx(beta_freq_range));
gamma_avg_power = mean(Pxx(gamma_freq_range));

    % 存储特征向量
features(i, :) = [num,FC,max_val, min_val, mean_val, std_val, rms_val, renyi,renyi_entropy,log_energy_entropy,shannon_entropy,tsallis_entropy,log_root_mean_square,teager_energy,kurtosis,skewness,complexity,hjorth_mobility,hjorth_activity,ZB_DE,ZB_TH,ZB_AL,ZB_BE,ZB_GA,class(i)];
features_table(i,:)=table(num,FC,max_val, min_val, mean_val, std_val, rms_val, renyi,renyi_entropy,log_energy_entropy,shannon_entropy,tsallis_entropy,log_root_mean_square,teager_energy,kurtosis,skewness,complexity,hjorth_mobility,hjorth_activity,ZB_DE,ZB_TH,ZB_AL,ZB_BE,ZB_GA,class(i));
end
feature_all=features;
features_table2=features_table;
end
