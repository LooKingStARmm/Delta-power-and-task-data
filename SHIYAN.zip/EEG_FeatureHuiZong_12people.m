%% 程序用来获得第二批16所有操作者两个实验的若干步的特征，需要调用EEG_feature24_func和EEG_Get_yuchuli两函数,最后汇总在一个矩阵中
clear all;
%% % % % % % % % % % % 加载实验一实验二数据 % % % % % % % % % % % % % %
tx1_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验一\19-1.xls');%%%%%%%%%%%%此处更改分段时间点%%%%%%%%%%%%%%%%%%%%%%%%此处更改分段时间点%%%%%%%%%%%%%%%%%%%%%%%%此处更改分段时间点%%%%%%%%%%%%
tx1_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验二\19-1-2.xls');
tx4_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验一\16-4.xls');
tx4_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验二\16-4-2.xls');
tx14_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验一\18-14.xls');
tx14_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验二\18-14-2.xls');
tx9_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验二\11-9-2.xls');
tx10_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验一\12-10.xls');
tx10_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验二\12-10-2.xls');
tx7_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验一\13-7.xls');
tx7_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验二\13-7-2.xls');
tx3_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验一\8-3.xls');
tx3_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验二\8-3-2.xls');
tx16_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验一\14-16.xls');
tx16_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验二\14-16-2.xls');
tx15_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验一\9-15.xls');
tx15_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验二\9-15-2.xls');
tx17_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验一\15-17.xls');
tx17_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验二\15-17-2.xls');
tx5_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验一\17-5.xls');
tx5_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验二\17-5-2.xls');
tx2_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验一\6-2.xls');
tx2_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验二\6-2-2.xls');
tx20_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验一\10-20.xls');
tx20_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验二\10-20-2.xls');
tx12_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验一\5-12.xls');
tx12_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验二\5-12-2.xls');
tx6_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验一\4-6.xls');
tx6_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验二\4-6-2.xls');
tx11_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验一\3-11.xls');
tx11_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验二\3-11-2.xls');
% tx1_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验一\6-2.xls');
% tx1_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第二批操作实验\实验二\6-2-2.xls');
%% 
% 定义切分的时间点%%%%%%%%%%%%此处更改分段时间点%%%%%%%%%%%%%%%%%%%%%%%%此处更改分段时间点%%%%%%%%%%%%%%%%%%%%%%%%此处更改分段时间点%%%%%%%%%%%%
%11号的步骤时间3-11
%
time_points11_1_start = [85	123	138	245	265	307	327	348	362	377	422	485	520];
time_points11_1_end=[123	138	245	265	307	327	348	362	377	422	485	520	598];
time_points11_2_start = [460	499	525	581	626	698	721	750	761	790	797	828	835	844	875	898	904	941];
time_points11_2_end=[499	525	581	626	698	721	750	761	790	797	828	835	844	875	898	904	941	982];
% class11_1=[3	2	1	3	1	2	3	2	3	3	1	2	3]';
% class11_2=[3	3	1	1	1	2	3	2	3	3	3	3	3	3	3	3	3	3]';
class11_1=[2 2 1 2 1 2 2 2 2 2 1 2 3]';
class11_2=[2 2 1 1 1 2 4 1 3 4 2 4 3 2 2 4 4 4]';
%}
%6号的步骤时间4-6
%
time_points6_1_start = [53	218	360	475	525	556	585	612	638	654	726	747];%少一步
time_points6_1_end=[218	228	475	525	556	585	612	638	654	726	747	793];
time_points6_2_start = [375	418	428	468	469	517	543	569	593	675	684	773	817	833	868	887	942	1019];
time_points6_2_end=[418	428	468	469	517	543	569	593	675	684	773	817	833	868	887	942	1019 1105];
class6_1=[1 1 1 1 2 1 1 1 1 1 1 2]';
class6_2=[2 4 2 4 2 1 4 2 1 2 1 1 2 1 4 1 1 1 ]';
%}

%4号的步骤时间16-4
%
time_points4_1_start = [25	51	59	82	100	120	136	159	166	173	197	207	313];
time_points4_1_end=[51	59	82	100	120	136	159	166	173	197	207	235	333];
time_points4_2_start = [388	467	477	484	520	564	579	612	625	665	672	745	775	783	799	828	835	889];
time_points4_2_end=[467	477	484	520	564	579	612	625	665	672	745	775	783	799	828	835	889	915];
class4_1=[4 4 2 2 4 2 1 3 4 4 4 3 4]';
class4_2=[1 4 4 1 3 4 2 4 2 4 1 1 1 1 1 4 2 2]';
%}
%14号的步骤时间18-14
%
time_points14_1_start = [25	50	59	105	118	131	145	163	175	182	234	246	267];
time_points14_1_end=[50	59	105	118	131	145	163	175	182	234	246	267	284];
time_points14_2_start = [382	416	447	485	512	545	568	597	622	655	665	679	686	697	721	736	746	779];
time_points14_2_end=[416	447	485	512	545	568	597	622	655	665	679	686	697	721	736	746	779	812];
class14_1=[1 4 1 1 1 4 3 2 4 2 1 1 3]';
class14_2=[4 1 2 3 4 2 4 1 3 1 4 4 2 3 4 2 4 4]';
%}
%9号的步骤时间,无实验一脑电数据11-9
%
time_points9_1_start = [100	133	144	178	191	214	235	251	260	280	313	328	356];
time_points9_1_end=[133	144	178	191	214	235	251	260	280	313	328	356	410];
time_points9_2_start = [425	470	477	500	527	565	590	614	641	674	682	733	743	750	780	803	805	844];
time_points9_2_end=[470	477	500	527	565	590	614	641	674	682	733	743	750	780	803	805	844	930];
% class9_1=[3	3	4	3	3	2	3	3	2	3	3	3	2]';
% class9_2=[2	3	2	3	2	2	4	3	3	3	2	3	3	3	3	3	3	1]';
class9_1=[3 3 4 4 3 1 3 2 1 3 3 3 1]';
class9_2=[3 4 2 2 1 1 4 3 3 3 2 3 4 3 2 4 3 1]';
%}
%10号的步骤时间12-10
%
time_points10_1_start = [55	71	84	109	155	174	187	203	213	218	237	248	270];
time_points10_1_end=[71	84	109	155	174	187	203	213	218	237	248	270	329];
time_points10_2_start = [353	362	379	438	680	713	727	756	768	794	801	814	825	833	848	870	873	910];
time_points10_2_end=[362	379	438	465	713	727	756	768	794	801	814	825	833	848	870	873	910	945];
class10_1=[4 2 4 1 4 4 4 4 4 4 4 4 4]';
class10_2=[1 2 1 3 4 4 4 4 4 3 4 2 4 4 3 3 4 2]';
% class10_1=[3	3	4	1	3	3	3	3	4	3	3	3	3]';
% class10_2=[2	3	1	3	4	3	3	3	3	3	3	3	3	3	3	3	3	3]';
%}
%1号的步骤时间19-1
%
time_points1_1_start = [35	66	86	125	148	181	201	223	234	251	296	317	338];
time_points1_1_end=[66	86	125	148	181	201	223	234	251	296	317	338	418];
time_points1_2_start = [378	412	427	438	462	514	528	559	580	632	650	677	691	701	738	755	766	811];
time_points1_2_end=[412	427	438	462	514	528	559	580	632	650	677	691	701	738	755	766	811	898];
class1_1=[3 1 4 2 2 3 2 3 2 2 2 4 1]';
class1_2=[4 3 4 4 2 3 3 3 2 2 3 2 3 1 3 2 3 1]';
% class1_1=[3	2	3	3	2	2	3	3	2	3	3	4	2]';
% class1_2=[3	3	4	3	3	3	3	3	2	2	3	3	3	3	3	3	3	1]';
%}
%7号的步骤时间13-7
%
time_points7_1_start = [25	50	57	70	82	100	113	130	137	144	167	176	194];
time_points7_1_end=[50	57	70	82	100	113	130	137	144	167	176	194	235];
time_points7_2_start = [379	409	467	473	496	535	555	581	592	603	609	639	647	652	670	675	701	737];
time_points7_2_end=[409	467	473	496	535	555	581	592	603	609	639	647	652	670	675	701	737	759];
class7_1=[4 4 3 4 4 4 4 1 4 4 4 4 2]';
class7_2=[4 1 4 4 4 4 4 4 4 4 3 4 4 4 4 1 4 3]';
% class7_1=[3	4	3	3	4	3	3	1	3	3	3	4	3]';
% class7_2=[3	1	4	3	3	3	4	3	4	3	3	3	3	3	4	2	3	4]';
%}
%3号的步骤时间8-3
%
time_points3_1_start = [33	67	85	117	132	161	174	205	221	275	303	335	376];
time_points3_1_end=[67	85	117	132	161	174	205	221	237	303	335	376	430];
time_points3_2_start = [370	407	520	537	572	619	654	691	708	745	765	800	820	853	875	906	920	960];
time_points3_2_end=[407	427	537	572	619	654	691	708	745	765	800	820	853	875	906	920	960	1014];
class3_1=[2 3 2 2 1 1 1 2 2 1 1 1 4]';
class3_2=[3 3 3 1 3 1 1 2 2 2 2 2 1 3 1 1 1 2]';
% class3_1=[3	2	2	3	1	1	1	2	2	2	2	1	4]';
% class3_2=[3	3	3	1	3	1	2	2	3	2	3	3	1	3	1	3	2	3]';
%}
%16号的步骤时间14-16
%
time_points16_1_start = [35	61	67	195	209	230	244	268	288	298	382	405	438];
time_points16_1_end=[61	67	91	209	230	244	268	288	298	382	405	438	510];
time_points16_2_start = [240	275	325	350	380	423	448	480	503	526	533	550	571	580	608	630	640	681];
time_points16_2_end=[275	325	350	380	423	448	480	503	526	533	550	571	580	608	630	640	681	736];
class16_1=[3 1 4 3 3 4 1 1 3 1 3 2 1]';
class16_2=[3 1 4 2 3 1 2 2 3 4 4 3 3 2 3 2 2 2]';
% class16_1=[3	1	4	3	3	3	1	1	3	1	3	2	1]';
% class16_2=[3	1	3	3	3	2	2	3	3	3	3	3	3	3	3	3	3	1]';
%}
%15号的步骤时间9-15
%
time_points15_1_start = [25	58	69	95	102	120	135	147	158	168	201	215	309];
time_points15_1_end=[58	69	95	102	120	135	147	158	168	201	215	240	361];
time_points15_2_start = [395	442	472	491	519	567	590	625	645	665	673	690	699	707	727	748	755	781];
time_points15_2_end=[442	472	491	519	567	590	625	645	665	673	690	699	707	727	748	755	781	827];
% class15_1=[3	3	2	3	4	3	4	3	1	3	3	3	2]';
% class15_2=[2	2	2	3	3	2	2	3	3	3	3	3	3	3	3	3	4	3]';
class15_1=[3 3 2 4 4 3 4 3 1 3 4 3 2]';
class15_2=[2 2 2 2 2 3 2 3 4 3 4 4 4 3 4 4 4 3]';
%}
%17号的步骤时间15-17
%
time_points17_1_start = [37	59	67	93	105	124	132	154	163	168	193	202	224];
time_points17_1_end=[59	67	93	105	124	132	154	163	168	193	202	224	262];
time_points17_2_start = [377	388	402	430	460	503	526	551	562	588	594	615	621	632	644	667	672	706];
time_points17_2_end=[388	402	430	460	503	526	551	562	588	594	615	621	632	644	667	672	706	752];
% class17_1=[3	4	4	3	3	2	3	2	4	3	3	3	4]';
% class17_2=[4	3	3	3	3	2	4	3	3	3	3	3	3	3	3	3	3	3]';
class17_1=[4 4 3 4 4 2 2 4 4 4 4 4 4]';
class17_2=[4 4 3 2 3 2 3 4 4 4 4 4 2 4 2 4 4 3]';
%}
%5号的步骤时间17-5
%
time_points5_1_start = [40	81	97	120	133	155	169	188	197	213	245	267	333];
time_points5_1_end=[81	97	120	133	155	169	188	197	213	245	267	288	380];
time_points5_2_start = [390	405	420	430	455	506	526	565	583	616	638	662	685	702	719	745	756	810];
time_points5_2_end=[405	420	430	455	506	526	565	583	616	638	662	685	702	719	745	756	810	848];
% class5_1=[2	2	2	3	3	3	3	3	2	3	3	4	3]';
% class5_2=[2	3	4	3	3	3	1	2	2	1	3	2	2	3	3	3	1	3]';
class5_1=[1 2 2 3 3 3 4 3 3 3 2 4 2]';
class5_2=[2 3 4 3 2 3 1 1 1 1 3 2 1 4 2 2 1 4]';
%}
%2号的步骤时间6-2
%
time_points2_1_start = [79	119	128	156	168	188	201	220	228	240	263	283	338];
time_points2_1_end=[119	128	156	168	188	201	220	228	240	263	283	307	373];
time_points2_2_start = [293	303	333	370	395	434	451	465	595	630	635	664	676	688	699	721	775	815];
time_points2_2_end=[303	333	370	395	434	451	465	595	630	635	664	676	688	699	721	729	801	865];
% class2_1=[3	3	3	3	1	3	3	3	3	3	3	3	3]';
% class2_2=[4	2	3	3	1	3	1	1	2	2	1	1	1	3	3	3	3	2]';
class2_1=[2 4 3 4 1 3 4 4 3 4 2 3 3]';
class2_2=[4 2 3 4 1 4 1 1 1 3 1 1 1 4 3 3 2 2]';
%}
%20号的步骤时间10-20
%
time_points20_1_start = [80	106	147	181	195	222	235	255	263	275	305	322	395];
time_points20_1_end=[106	118	181	195	222	235	255	263	275	305	322	353	416];
time_points20_2_start = [350	385	395	427	478	514	534	617	629	695	715	760	773	778	810	834	843	903];
time_points20_2_end=[385	395	427	444	514	534	565	629	654	715	760	773	778	810	834	843	903	949];
% class20_1=[3	3	3	3	2	2	3	3	3	3	3	1	3]';
% class20_2=[3	3	2	2	3	3	3	2	2	2	2	2	3	3	3	3	2	3]';
class20_1=[4 3 3 3 2 2 3 4 3 3 3 1 3]';
class20_2=[3 4 2 1 4 4 3 2 2 2 2 1 4 2 2 2 1 3]';
%}
% 12号的步骤时间5-12
%
time_points12_1_start = [45	67	91	119	156	180	192	215	225	240	293	308	345];
time_points12_1_end=[67	91	119	156	180	192	215	225	240	293	308	345	444];
time_points12_2_start = [364	405	420	505	520	598	619	663	680	768	798	832	842	852	974	986	1007	1097];
time_points12_2_end=[405	420	505	520	598	619	663	680	768	798	832	842	852	974	986	1007	1065	1120];
% class12_1=[2,1,2,1,1,1,1,1,1,1,1,1,2]';
% class12_2=[2	1	2	3	2	1	1	1	2	2	2	1	1	2	2	1	1	3]';
class12_1=[1 1 2 1 3 1 2 1 2 2 3 2 1]';
class12_2=[1 3 1 3 1 3 1 3 1 1 1 3 3 1 1 1 2 1]';
%}
%% 1hao
rawdata1_1=tx1_1(:,13);
rawdata1_2=tx1_2(:,13);
%%通过调用函数获得feature矩阵,下面是实验一六种波形分别获得的特征最后汇总在feature——all1中；
[Delta1,Theta1,Alpha1,Beta1,Gamma1,rawdata_yuchuli1,t1]= EEG_Get_yuchuli(rawdata1_1);
[feature1_1,table1_1] = EEG_feature24_func(rawdata_yuchuli1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points1_1_start,time_points1_1_end,class1_1);
[feature1_2,table1_2] = EEG_feature24_func(Delta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points1_1_start,time_points1_1_end,class1_1);%为什么获得的是复数矩阵？
[feature1_3,table1_3] = EEG_feature24_func(Theta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points1_1_start,time_points1_1_end,class1_1);
[feature1_4,table1_4] = EEG_feature24_func(Alpha1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points1_1_start,time_points1_1_end,class1_1);
[feature1_5,table1_5] = EEG_feature24_func(Beta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points1_1_start,time_points1_1_end,class1_1);
[feature1_6,table1_6] = EEG_feature24_func(Gamma1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points1_1_start,time_points1_1_end,class1_1);
feature1_7=EEG_avg_power_func(rawdata_yuchuli1,time_points1_1_start,time_points1_1_end);
C1 = horzcat(feature1_2(:,1:end-6),feature1_3(:,2:end-6),feature1_4(:,2:end-6),feature1_5(:,2:end-6),feature1_6(:,2:end-6),feature1_7,feature1_1(:,2:end));%横向合并
feature_all1=real(C1);
% C = vertcat(feature1, feature2);%纵向合并
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata1_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points1_2_start,time_points1_2_end,class1_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points1_2_start,time_points1_2_end,class1_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points1_2_start,time_points1_2_end,class1_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points1_2_start,time_points1_2_end,class1_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points1_2_start,time_points1_2_end,class1_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points1_2_start,time_points1_2_end,class1_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points1_2_start,time_points1_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_1hao=vertcat(feature_all1,feature_all2);%将上面两实验特征纵向合并 %%%%%%%%%%%%此处更改分段时间点%%%%%%%%%%%%%%%%%%%%%%%%此处更改分段时间点%%%%%%%%%%%%%%%%%%%%%%%%此处更改分段时间点%%%%%%%%%%%%

%% 2hao
rawdata2_1=tx2_1(:,13);
rawdata2_2=tx2_2(:,13);
%%通过调用函数获得feature矩阵,下面是实验一六种波形分别获得的特征最后汇总在feature——all1中；
[Delta1,Theta1,Alpha1,Beta1,Gamma1,rawdata_yuchuli1,t1]= EEG_Get_yuchuli(rawdata2_1);
feature1_1 = EEG_feature24_func(rawdata_yuchuli1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points2_1_start,time_points2_1_end,class2_1);
feature1_2 = EEG_feature24_func(Delta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points2_1_start,time_points2_1_end,class2_1);%为什么获得的是复数矩阵？
feature1_3 = EEG_feature24_func(Theta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points2_1_start,time_points2_1_end,class2_1);
feature1_4 = EEG_feature24_func(Alpha1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points2_1_start,time_points2_1_end,class2_1);
feature1_5 = EEG_feature24_func(Beta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points2_1_start,time_points2_1_end,class2_1);
feature1_6 = EEG_feature24_func(Gamma1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points2_1_start,time_points2_1_end,class2_1);
feature1_7=EEG_avg_power_func(rawdata_yuchuli1,time_points2_1_start,time_points2_1_end);
C1 = horzcat(feature1_2(:,1:end-6),feature1_3(:,2:end-6),feature1_4(:,2:end-6),feature1_5(:,2:end-6),feature1_6(:,2:end-6),feature1_7,feature1_1(:,2:end));%横向合并
feature_all1=real(C1);
% C = vertcat(feature1, feature2);%纵向合并
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata2_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points2_2_start,time_points2_2_end,class2_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points2_2_start,time_points2_2_end,class2_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points2_2_start,time_points2_2_end,class2_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points2_2_start,time_points2_2_end,class2_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points2_2_start,time_points2_2_end,class2_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points2_2_start,time_points2_2_end,class2_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points2_2_start,time_points2_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_2hao=vertcat(feature_all1,feature_all2);
%% 3hao
rawdata3_1=tx3_1(:,13);
rawdata3_2=tx3_2(:,13);
[Delta1,Theta1,Alpha1,Beta1,Gamma1,rawdata_yuchuli1,t1]= EEG_Get_yuchuli(rawdata3_1);
feature1_1 = EEG_feature24_func(rawdata_yuchuli1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points3_1_start,time_points3_1_end,class3_1);
feature1_2 = EEG_feature24_func(Delta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points3_1_start,time_points3_1_end,class3_1);%为什么获得的是复数矩阵？
feature1_3 = EEG_feature24_func(Theta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points3_1_start,time_points3_1_end,class3_1);
feature1_4 = EEG_feature24_func(Alpha1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points3_1_start,time_points3_1_end,class3_1);
feature1_5 = EEG_feature24_func(Beta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points3_1_start,time_points3_1_end,class3_1);
feature1_6 = EEG_feature24_func(Gamma1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points3_1_start,time_points3_1_end,class3_1);
feature1_7=EEG_avg_power_func(rawdata_yuchuli1,time_points3_1_start,time_points3_1_end);
C1 = horzcat(feature1_2(:,1:end-6),feature1_3(:,2:end-6),feature1_4(:,2:end-6),feature1_5(:,2:end-6),feature1_6(:,2:end-6),feature1_7,feature1_1(:,2:end));%横向合并
feature_all1=real(C1);
% C = vertcat(feature1, feature2);%纵向合并
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata3_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points3_2_start,time_points3_2_end,class3_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points3_2_start,time_points3_2_end,class3_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points3_2_start,time_points3_2_end,class3_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points3_2_start,time_points3_2_end,class3_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points3_2_start,time_points3_2_end,class3_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points3_2_start,time_points3_2_end,class3_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points3_2_start,time_points3_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_3hao=vertcat(feature_all1,feature_all2);
%% 4hao
rawdata4_1=tx4_1(:,13);
rawdata4_2=tx4_2(:,13);
[Delta1,Theta1,Alpha1,Beta1,Gamma1,rawdata_yuchuli1,t1]= EEG_Get_yuchuli(rawdata4_1);
feature1_1 = EEG_feature24_func(rawdata_yuchuli1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points4_1_start,time_points4_1_end,class4_1);
feature1_2 = EEG_feature24_func(Delta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points4_1_start,time_points4_1_end,class4_1);%为什么获得的是复数矩阵？
feature1_3 = EEG_feature24_func(Theta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points4_1_start,time_points4_1_end,class4_1);
feature1_4 = EEG_feature24_func(Alpha1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points4_1_start,time_points4_1_end,class4_1);
feature1_5 = EEG_feature24_func(Beta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points4_1_start,time_points4_1_end,class4_1);
feature1_6 = EEG_feature24_func(Gamma1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points4_1_start,time_points4_1_end,class4_1);
feature1_7=EEG_avg_power_func(rawdata_yuchuli1,time_points4_1_start,time_points4_1_end);
C1 = horzcat(feature1_2(:,1:end-6),feature1_3(:,2:end-6),feature1_4(:,2:end-6),feature1_5(:,2:end-6),feature1_6(:,2:end-6),feature1_7,feature1_1(:,2:end));%横向合并
feature_all1=real(C1);
% C = vertcat(feature1, feature2);%纵向合并
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata4_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points4_2_start,time_points4_2_end,class4_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points4_2_start,time_points4_2_end,class4_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points4_2_start,time_points4_2_end,class4_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points4_2_start,time_points4_2_end,class4_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points4_2_start,time_points4_2_end,class4_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points4_2_start,time_points4_2_end,class4_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points4_2_start,time_points4_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_4hao=vertcat(feature_all1,feature_all2);
%% 5hao
rawdata5_1=tx5_1(:,13);
rawdata5_2=tx5_2(:,13);
[Delta1,Theta1,Alpha1,Beta1,Gamma1,rawdata_yuchuli1,t1]= EEG_Get_yuchuli(rawdata5_1);
feature1_1 = EEG_feature24_func(rawdata_yuchuli1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points5_1_start,time_points5_1_end,class5_1);
feature1_2 = EEG_feature24_func(Delta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points5_1_start,time_points5_1_end,class5_1);%为什么获得的是复数矩阵？
feature1_3 = EEG_feature24_func(Theta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points5_1_start,time_points5_1_end,class5_1);
feature1_4 = EEG_feature24_func(Alpha1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points5_1_start,time_points5_1_end,class5_1);
feature1_5 = EEG_feature24_func(Beta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points5_1_start,time_points5_1_end,class5_1);
feature1_6 = EEG_feature24_func(Gamma1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points5_1_start,time_points5_1_end,class5_1);
feature1_7=EEG_avg_power_func(rawdata_yuchuli1,time_points5_1_start,time_points5_1_end);
C1 = horzcat(feature1_2(:,1:end-6),feature1_3(:,2:end-6),feature1_4(:,2:end-6),feature1_5(:,2:end-6),feature1_6(:,2:end-6),feature1_7,feature1_1(:,2:end));%横向合并
feature_all1=real(C1);
% C = vertcat(feature1, feature2);%纵向合并
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata5_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points5_2_start,time_points5_2_end,class5_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points5_2_start,time_points5_2_end,class5_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points5_2_start,time_points5_2_end,class5_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points5_2_start,time_points5_2_end,class5_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points5_2_start,time_points5_2_end,class5_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points5_2_start,time_points5_2_end,class5_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points5_2_start,time_points5_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_5hao=vertcat(feature_all1,feature_all2);
%% 6hao
rawdata6_1=tx6_1(:,13);
rawdata6_2=tx6_2(:,13);
[Delta1,Theta1,Alpha1,Beta1,Gamma1,rawdata_yuchuli1,t1]= EEG_Get_yuchuli(rawdata6_1);
feature1_1 = EEG_feature24_func(rawdata_yuchuli1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points6_1_start,time_points6_1_end,class6_1);
feature1_2 = EEG_feature24_func(Delta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points6_1_start,time_points6_1_end,class6_1);%为什么获得的是复数矩阵？
feature1_3 = EEG_feature24_func(Theta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points6_1_start,time_points6_1_end,class6_1);
feature1_4 = EEG_feature24_func(Alpha1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points6_1_start,time_points6_1_end,class6_1);
feature1_5 = EEG_feature24_func(Beta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points6_1_start,time_points6_1_end,class6_1);
feature1_6 = EEG_feature24_func(Gamma1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points6_1_start,time_points6_1_end,class6_1);
feature1_7=EEG_avg_power_func(rawdata_yuchuli1,time_points6_1_start,time_points6_1_end);
C1 = horzcat(feature1_2(:,1:end-6),feature1_3(:,2:end-6),feature1_4(:,2:end-6),feature1_5(:,2:end-6),feature1_6(:,2:end-6),feature1_7,feature1_1(:,2:end));%横向合并
feature_all1=real(C1);
% C = vertcat(feature1, feature2);%纵向合并
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata6_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points6_2_start,time_points6_2_end,class6_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points6_2_start,time_points6_2_end,class6_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points6_2_start,time_points6_2_end,class6_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points6_2_start,time_points6_2_end,class6_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points6_2_start,time_points6_2_end,class6_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points6_2_start,time_points6_2_end,class6_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points6_2_start,time_points6_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_6hao=vertcat(feature_all1,feature_all2);
%% 7hao
rawdata7_1=tx7_1(:,13);
rawdata7_2=tx7_2(:,13);
[Delta1,Theta1,Alpha1,Beta1,Gamma1,rawdata_yuchuli1,t1]= EEG_Get_yuchuli(rawdata7_1);
feature1_1 = EEG_feature24_func(rawdata_yuchuli1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points7_1_start,time_points7_1_end,class7_1);
feature1_2 = EEG_feature24_func(Delta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points7_1_start,time_points7_1_end,class7_1);%为什么获得的是复数矩阵？
feature1_3 = EEG_feature24_func(Theta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points7_1_start,time_points7_1_end,class7_1);
feature1_4 = EEG_feature24_func(Alpha1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points7_1_start,time_points7_1_end,class7_1);
feature1_5 = EEG_feature24_func(Beta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points7_1_start,time_points7_1_end,class7_1);
feature1_6 = EEG_feature24_func(Gamma1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points7_1_start,time_points7_1_end,class7_1);
feature1_7=EEG_avg_power_func(rawdata_yuchuli1,time_points7_1_start,time_points7_1_end);
C1 = horzcat(feature1_2(:,1:end-6),feature1_3(:,2:end-6),feature1_4(:,2:end-6),feature1_5(:,2:end-6),feature1_6(:,2:end-6),feature1_7,feature1_1(:,2:end));%横向合并
feature_all1=real(C1);
% C = vertcat(feature1, feature2);%纵向合并
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata7_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points7_2_start,time_points7_2_end,class7_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points7_2_start,time_points7_2_end,class7_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points7_2_start,time_points7_2_end,class7_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points7_2_start,time_points7_2_end,class7_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points7_2_start,time_points7_2_end,class7_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points7_2_start,time_points7_2_end,class7_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points7_2_start,time_points7_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_7hao=vertcat(feature_all1,feature_all2);
%% 10hao
rawdata10_1=tx10_1(:,13);
rawdata10_2=tx10_2(:,13);
[Delta1,Theta1,Alpha1,Beta1,Gamma1,rawdata_yuchuli1,t1]= EEG_Get_yuchuli(rawdata10_1);
feature1_1 = EEG_feature24_func(rawdata_yuchuli1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points10_1_start,time_points10_1_end,class10_1);
feature1_2 = EEG_feature24_func(Delta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points10_1_start,time_points10_1_end,class10_1);%为什么获得的是复数矩阵？
feature1_3 = EEG_feature24_func(Theta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points10_1_start,time_points10_1_end,class10_1);
feature1_4 = EEG_feature24_func(Alpha1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points10_1_start,time_points10_1_end,class10_1);
feature1_5 = EEG_feature24_func(Beta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points10_1_start,time_points10_1_end,class10_1);
feature1_6 = EEG_feature24_func(Gamma1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points10_1_start,time_points10_1_end,class10_1);
feature1_7=EEG_avg_power_func(rawdata_yuchuli1,time_points10_1_start,time_points10_1_end);
C1 = horzcat(feature1_2(:,1:end-6),feature1_3(:,2:end-6),feature1_4(:,2:end-6),feature1_5(:,2:end-6),feature1_6(:,2:end-6),feature1_7,feature1_1(:,2:end));%横向合并
feature_all1=real(C1);
% C = vertcat(feature1, feature2);%纵向合并
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata10_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points10_2_start,time_points10_2_end,class10_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points10_2_start,time_points10_2_end,class10_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points10_2_start,time_points10_2_end,class10_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points10_2_start,time_points10_2_end,class10_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points10_2_start,time_points10_2_end,class10_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points10_2_start,time_points10_2_end,class10_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points10_2_start,time_points10_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_10hao=vertcat(feature_all1,feature_all2);
%% 11hao
rawdata11_1=tx11_1(:,13);
rawdata11_2=tx11_2(:,13);
[Delta1,Theta1,Alpha1,Beta1,Gamma1,rawdata_yuchuli1,t1]= EEG_Get_yuchuli(rawdata11_1);
feature1_1 = EEG_feature24_func(rawdata_yuchuli1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points11_1_start,time_points11_1_end,class11_1);
feature1_2 = EEG_feature24_func(Delta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points11_1_start,time_points11_1_end,class11_1);%为什么获得的是复数矩阵？
feature1_3 = EEG_feature24_func(Theta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points11_1_start,time_points11_1_end,class11_1);
feature1_4 = EEG_feature24_func(Alpha1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points11_1_start,time_points11_1_end,class11_1);
feature1_5 = EEG_feature24_func(Beta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points11_1_start,time_points11_1_end,class11_1);
feature1_6 = EEG_feature24_func(Gamma1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points11_1_start,time_points11_1_end,class11_1);
feature1_7=EEG_avg_power_func(rawdata_yuchuli1,time_points11_1_start,time_points11_1_end);
C1 = horzcat(feature1_2(:,1:end-6),feature1_3(:,2:end-6),feature1_4(:,2:end-6),feature1_5(:,2:end-6),feature1_6(:,2:end-6),feature1_7,feature1_1(:,2:end));%横向合并
feature_all1=real(C1);
% C = vertcat(feature1, feature2);%纵向合并
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata11_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points11_2_start,time_points11_2_end,class11_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points11_2_start,time_points11_2_end,class11_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points11_2_start,time_points11_2_end,class11_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points11_2_start,time_points11_2_end,class11_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points11_2_start,time_points11_2_end,class11_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points11_2_start,time_points11_2_end,class11_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points11_2_start,time_points11_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_11hao=vertcat(feature_all1,feature_all2);
%% 12hao
rawdata12_1=tx12_1(:,13);
rawdata12_2=tx12_2(:,13);
[Delta1,Theta1,Alpha1,Beta1,Gamma1,rawdata_yuchuli1,t1]= EEG_Get_yuchuli(rawdata12_1);
feature1_1 = EEG_feature24_func(rawdata_yuchuli1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points12_1_start,time_points12_1_end,class12_1);
feature1_2 = EEG_feature24_func(Delta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points12_1_start,time_points12_1_end,class12_1);%为什么获得的是复数矩阵？
feature1_3 = EEG_feature24_func(Theta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points12_1_start,time_points12_1_end,class12_1);
feature1_4 = EEG_feature24_func(Alpha1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points12_1_start,time_points12_1_end,class12_1);
feature1_5 = EEG_feature24_func(Beta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points12_1_start,time_points12_1_end,class12_1);
feature1_6 = EEG_feature24_func(Gamma1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points12_1_start,time_points12_1_end,class12_1);
feature1_7=EEG_avg_power_func(rawdata_yuchuli1,time_points12_1_start,time_points12_1_end);
C1 = horzcat(feature1_2(:,1:end-6),feature1_3(:,2:end-6),feature1_4(:,2:end-6),feature1_5(:,2:end-6),feature1_6(:,2:end-6),feature1_7,feature1_1(:,2:end));%横向合并
feature_all1=real(C1);
% C = vertcat(feature1, feature2);%纵向合并
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata12_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points12_2_start,time_points12_2_end,class12_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points12_2_start,time_points12_2_end,class12_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points12_2_start,time_points12_2_end,class12_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points12_2_start,time_points12_2_end,class12_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points12_2_start,time_points12_2_end,class12_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points12_2_start,time_points12_2_end,class12_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points12_2_start,time_points12_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_12hao=vertcat(feature_all1,feature_all2);

%% 14hao
rawdata14_1=tx14_1(:,13);
rawdata14_2=tx14_2(:,13);
[Delta1,Theta1,Alpha1,Beta1,Gamma1,rawdata_yuchuli1,t1]= EEG_Get_yuchuli(rawdata14_1);
feature1_1 = EEG_feature24_func(rawdata_yuchuli1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points14_1_start,time_points14_1_end,class14_1);
feature1_2 = EEG_feature24_func(Delta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points14_1_start,time_points14_1_end,class14_1);%为什么获得的是复数矩阵？
feature1_3 = EEG_feature24_func(Theta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points14_1_start,time_points14_1_end,class14_1);
feature1_4 = EEG_feature24_func(Alpha1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points14_1_start,time_points14_1_end,class14_1);
feature1_5 = EEG_feature24_func(Beta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points14_1_start,time_points14_1_end,class14_1);
feature1_6 = EEG_feature24_func(Gamma1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points14_1_start,time_points14_1_end,class14_1);
feature1_7=EEG_avg_power_func(rawdata_yuchuli1,time_points14_1_start,time_points14_1_end);
C1 = horzcat(feature1_2(:,1:end-6),feature1_3(:,2:end-6),feature1_4(:,2:end-6),feature1_5(:,2:end-6),feature1_6(:,2:end-6),feature1_7,feature1_1(:,2:end));%横向合并
feature_all1=real(C1);
% C = vertcat(feature1, feature2);%纵向合并
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata14_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points14_2_start,time_points14_2_end,class14_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points14_2_start,time_points14_2_end,class14_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points14_2_start,time_points14_2_end,class14_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points14_2_start,time_points14_2_end,class14_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points14_2_start,time_points14_2_end,class14_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points14_2_start,time_points14_2_end,class14_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points14_2_start,time_points14_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_14hao=vertcat(feature_all1,feature_all2);
%% 15hao
rawdata15_1=tx15_1(:,13);
rawdata15_2=tx15_2(:,13);
[Delta1,Theta1,Alpha1,Beta1,Gamma1,rawdata_yuchuli1,t1]= EEG_Get_yuchuli(rawdata15_1);
feature1_1 = EEG_feature24_func(rawdata_yuchuli1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points15_1_start,time_points15_1_end,class15_1);
feature1_2 = EEG_feature24_func(Delta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points15_1_start,time_points15_1_end,class15_1);%为什么获得的是复数矩阵？
feature1_3 = EEG_feature24_func(Theta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points15_1_start,time_points15_1_end,class15_1);
feature1_4 = EEG_feature24_func(Alpha1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points15_1_start,time_points15_1_end,class15_1);
feature1_5 = EEG_feature24_func(Beta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points15_1_start,time_points15_1_end,class15_1);
feature1_6 = EEG_feature24_func(Gamma1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points15_1_start,time_points15_1_end,class15_1);
feature1_7=EEG_avg_power_func(rawdata_yuchuli1,time_points15_1_start,time_points15_1_end);
C1 = horzcat(feature1_2(:,1:end-6),feature1_3(:,2:end-6),feature1_4(:,2:end-6),feature1_5(:,2:end-6),feature1_6(:,2:end-6),feature1_7,feature1_1(:,2:end));%横向合并
feature_all1=real(C1);
% C = vertcat(feature1, feature2);%纵向合并
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata15_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points15_2_start,time_points15_2_end,class15_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points15_2_start,time_points15_2_end,class15_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points15_2_start,time_points15_2_end,class15_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points15_2_start,time_points15_2_end,class15_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points15_2_start,time_points15_2_end,class15_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points15_2_start,time_points15_2_end,class15_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points15_2_start,time_points15_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_15hao=vertcat(feature_all1,feature_all2);
%% 16hao
rawdata16_1=tx16_1(:,13);
rawdata16_2=tx16_2(:,13);
[Delta1,Theta1,Alpha1,Beta1,Gamma1,rawdata_yuchuli1,t1]= EEG_Get_yuchuli(rawdata16_1);
feature1_1 = EEG_feature24_func(rawdata_yuchuli1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points16_1_start,time_points16_1_end,class16_1);
feature1_2 = EEG_feature24_func(Delta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points16_1_start,time_points16_1_end,class16_1);%为什么获得的是复数矩阵？
feature1_3 = EEG_feature24_func(Theta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points16_1_start,time_points16_1_end,class16_1);
feature1_4 = EEG_feature24_func(Alpha1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points16_1_start,time_points16_1_end,class16_1);
feature1_5 = EEG_feature24_func(Beta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points16_1_start,time_points16_1_end,class16_1);
feature1_6 = EEG_feature24_func(Gamma1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points16_1_start,time_points16_1_end,class16_1);
feature1_7=EEG_avg_power_func(rawdata_yuchuli1,time_points16_1_start,time_points16_1_end);
C1 = horzcat(feature1_2(:,1:end-6),feature1_3(:,2:end-6),feature1_4(:,2:end-6),feature1_5(:,2:end-6),feature1_6(:,2:end-6),feature1_7,feature1_1(:,2:end));%横向合并
feature_all1=real(C1);
% C = vertcat(feature1, feature2);%纵向合并
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata16_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points16_2_start,time_points16_2_end,class16_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points16_2_start,time_points16_2_end,class16_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points16_2_start,time_points16_2_end,class16_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points16_2_start,time_points16_2_end,class16_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points16_2_start,time_points16_2_end,class16_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points16_2_start,time_points16_2_end,class16_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points16_2_start,time_points16_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_16hao=vertcat(feature_all1,feature_all2);
%% 17hao
rawdata17_1=tx17_1(:,13);
rawdata17_2=tx17_2(:,13);
[Delta1,Theta1,Alpha1,Beta1,Gamma1,rawdata_yuchuli1,t1]= EEG_Get_yuchuli(rawdata17_1);
feature1_1 = EEG_feature24_func(rawdata_yuchuli1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points17_1_start,time_points17_1_end,class17_1);
feature1_2 = EEG_feature24_func(Delta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points17_1_start,time_points17_1_end,class17_1);%为什么获得的是复数矩阵？
feature1_3 = EEG_feature24_func(Theta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points17_1_start,time_points17_1_end,class17_1);
feature1_4 = EEG_feature24_func(Alpha1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points17_1_start,time_points17_1_end,class17_1);
feature1_5 = EEG_feature24_func(Beta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points17_1_start,time_points17_1_end,class17_1);
feature1_6 = EEG_feature24_func(Gamma1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points17_1_start,time_points17_1_end,class17_1);
feature1_7=EEG_avg_power_func(rawdata_yuchuli1,time_points17_1_start,time_points17_1_end);
C1 = horzcat(feature1_2(:,1:end-6),feature1_3(:,2:end-6),feature1_4(:,2:end-6),feature1_5(:,2:end-6),feature1_6(:,2:end-6),feature1_7,feature1_1(:,2:end));%横向合并
feature_all1=real(C1);
% C = vertcat(feature1, feature2);%纵向合并
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata17_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points17_2_start,time_points17_2_end,class17_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points17_2_start,time_points17_2_end,class17_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points17_2_start,time_points17_2_end,class17_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points17_2_start,time_points17_2_end,class17_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points17_2_start,time_points17_2_end,class17_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points17_2_start,time_points17_2_end,class17_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points17_2_start,time_points17_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_17hao=vertcat(feature_all1,feature_all2);
%% 20hao
rawdata20_1=tx20_1(:,13);
rawdata20_2=tx20_2(:,13);
[Delta1,Theta1,Alpha1,Beta1,Gamma1,rawdata_yuchuli1,t1]= EEG_Get_yuchuli(rawdata20_1);
feature1_1 = EEG_feature24_func(rawdata_yuchuli1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points20_1_start,time_points20_1_end,class20_1);
feature1_2 = EEG_feature24_func(Delta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points20_1_start,time_points20_1_end,class20_1);%为什么获得的是复数矩阵？
feature1_3 = EEG_feature24_func(Theta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points20_1_start,time_points20_1_end,class20_1);
feature1_4 = EEG_feature24_func(Alpha1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points20_1_start,time_points20_1_end,class20_1);
feature1_5 = EEG_feature24_func(Beta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points20_1_start,time_points20_1_end,class20_1);
feature1_6 = EEG_feature24_func(Gamma1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points20_1_start,time_points20_1_end,class20_1);
feature1_7=EEG_avg_power_func(rawdata_yuchuli1,time_points20_1_start,time_points20_1_end);
C1 = horzcat(feature1_2(:,1:end-6),feature1_3(:,2:end-6),feature1_4(:,2:end-6),feature1_5(:,2:end-6),feature1_6(:,2:end-6),feature1_7,feature1_1(:,2:end));%横向合并
feature_all1=real(C1);
% C = vertcat(feature1, feature2);%纵向合并
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata20_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points20_2_start,time_points20_2_end,class20_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points20_2_start,time_points20_2_end,class20_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points20_2_start,time_points20_2_end,class20_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points20_2_start,time_points20_2_end,class20_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points20_2_start,time_points20_2_end,class20_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points20_2_start,time_points20_2_end,class20_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points20_2_start,time_points20_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_20hao=vertcat(feature_all1,feature_all2);
%% 9hao
rawdata9_2=tx9_2(:,13);
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata9_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points9_2_start,time_points9_2_end,class9_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points9_2_start,time_points9_2_end,class9_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points9_2_start,time_points9_2_end,class9_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points9_2_start,time_points9_2_end,class9_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points9_2_start,time_points9_2_end,class9_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points9_2_start,time_points9_2_end,class9_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points9_2_start,time_points9_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_9hao=vertcat(feature_all2);

data=vertcat(feature_all_1hao,feature_all_2hao,feature_all_3hao,feature_all_4hao,feature_all_5hao,feature_all_6hao,feature_all_7hao,feature_all_9hao,feature_all_10hao,feature_all_11hao,feature_all_12hao,feature_all_14hao,feature_all_15hao,feature_all_16hao,feature_all_17hao,feature_all_20hao);
% 检查数据是否包含 NaN 或 inf 数据点
has_nan = any(isnan(data(:))); % 是否存在 NaN
has_inf = any(isinf(data(:))); % 是否存在 inf

% 如果数据包含 NaN 或 inf 数据点，则删除包含这些数据点的列
if has_nan || has_inf
    % 找到包含 NaN 或 inf 数据点的列
    nan_cols = any(isnan(data), 1); % 包含 NaN 数据点的列
    inf_cols = any(isinf(data), 1); % 包含 inf 数据点的列
    % 删除这些列
    data(:, nan_cols | inf_cols) = [];
end
%% 进行特征归一化消除个体差异

% 对数据集第2~4列进行归一化处理
data_normalized = data;
data_normalized(:,2:end-1) = normalize(data(:,2:end-1));

feature_all_ALLhao=data_normalized;

rawdata_P1_1=[rawdata1_1 rawdata2_1];