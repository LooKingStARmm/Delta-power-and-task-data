%% 程序用来获得第二批16所有操作者两个实验的若干步的特征，需要调用EEG_feature24_func和EEG_Get_yuchuli两函数,最后汇总在一个矩阵中
clear all;
%% % % % % % % % % % % 加载实验一实验二数据 % % % % % % % % % % % % % %
% txP1_2_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\2-2.xls');
txP1_2_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\2-2.xls');
% txP1_3_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\实验一\8-3.xls');
txP1_3_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\3-2.xls');
% txP1_4_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\实验一\16-4.xls');
txP1_4_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\4-2.xls');
% txP1_5_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\实验一\19-1.xls');%%%%%%%%%%%%此处更改分段时间点%%%%%%%%%%%%%%%%%%%%%%%%此处更改分段时间点%%%%%%%%%%%%%%%%%%%%%%%%此处更改分段时间点%%%%%%%%%%%%
txP1_5_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\5-2.xls');
% txP1_6_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\实验一\4-6.xls');
txP1_6_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\6-2.xls');
% txP1_7_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\实验一\13-7.xls');
txP1_7_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\7-2.xls');
% txP1_8_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\实验一\18-14.xls');
txP1_8_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\8-2.xls');
% txP1_9_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\实验一\18-14.xls');
txP1_9_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\9-2.xls');
% txP1_10_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\实验一\12-10.xls');
txP1_10_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\10-2.xls');
% txP1_13_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\实验一\12-10.xls');
txP1_13_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\13-2.xls');
% txP1_14_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\实验一\12-10.xls');
txP1_14_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\14-2.xls');
% txP1_15_1=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\实验一\12-10.xls');
txP1_15_2=xlsread('C:\Users\dell\Desktop\数据\脑电数据\第一批操作实验\15-2.xls');
% 定义切分的时间点%%%%%%%%%%%%此处更改分段时间点%%%%%%%%%%%%%%%%%%%%%%%%此处更改分段时间点%%%%%%%%%%%%%%%%%%%%%%%%此处更改分段时间点%%%%%%%%%%%%
%2号的步骤时间
%
time_points2_2_start = [384	478	486	524	527	552	586	603	635	645	666	677	684	702	711	719	738	758 
];
time_points2_2_end=[478	486	524	527	552	586	603	635	645	666	677	684	702	711	719	738	758	764 
];
% class2_2=[4	2	3	3	1	3	1	1	2	2	1	1	1	3	3	3	3	2]';
class2_2=[4 2 3 4 1 4 1 1 1 3 1 1 1 4 3 3 2 2 ]';
%}
%3号的步骤时间
%
time_points3_2_start = [381	393	411	433	445	468	505	540	573	589	600	622	635	865	876	893	919	920 
];
time_points3_2_end=[393	411	433	445	468	505	540	573	589	600	622	635	865	876	893	919	920	965 
];
class3_2=[2 2 1 1 1 2 4 1 3 4 2 4 3 2 2 4 4 4 ]';
%}
%4号的步骤时间
%
time_points4_2_start = [415	432	452	488	499	527	574	595	636	648	672	687	697	715	727	735	758	784 
];
time_points4_2_end=[432	452	488	499	527	574	595	636	648	672	687	697	715	727	735	758	784	795 
];
class4_2=[2 4 2 4 2 1 4 2 1 2 1 1 2 1 4 1 1 1 ]';
%}

%5号的步骤时间
%
time_points5_2_start = [367	377	379	401	416	440	473	492	523	530	555	572	610	632	640	656	674	704 
];
time_points5_2_end=[377	379	401	416	440	473	492	523	530	555	572	610	632	640	656	674	704	709 
];
class5_2=[1 4 4 1 3 4 2 4 2 4 1 1 1 1 1 4 2 2 ]';
%}
%6号的步骤时间
%
time_points6_2_start = [457	468	496	519	525	563	605	638	674	684	700	717	726	736	744	747	760	772 
];
time_points6_2_end=[468	496	519	525	563	605	638	674	684	700	717	726	736	744	747	760	772	789 
];
class6_2=[4 1 2 3 4 2 4 1 3 1 4 4 2 3 4 2 4 4 ]';
%}
%7号的步骤时间
%
time_points7_2_start = [333	352	372	397	407	415	420	454	471	504	525	552	561	582	606	627	627	640
];
time_points7_2_end=[352	372	397	407	415	420	440	471	504	525	534	561	582	595	627	640	640	650
];
class7_2=[3 4 2 2 1 1 4 3 3 3 2 3 4 3 2 4 3 1 ]';
%}
%8号的步骤时间
%
time_points8_2_start = [336	351	390	406	425	449	518	543	584	603	623	644	656	680	689	706	730	751 
];
time_points8_2_end=[351	390	406	425	449	518	543	584	603	623	644	656	680	689	706	730	751	761 
];
class8_2=[1 2 1 3 4 4 4 4 4 3 4 2 4 4 3 3 4 2 ]';
%}
%9号的步骤时间
%
time_points9_2_start = [381	396	428	461	463	486	527	545	585	602	622	634	643	654	660	664	680	701 
];
time_points9_2_end=[396	428	461	463	486	527	545	585	602	622	634	643	654	660	664	680	701	708 
];
class9_2=[4 3 4 4 2 3 3 3 2 2 3 2 3 1 3 2 3 1 ]';
%10号的步骤时间
%
time_points10_2_start = [372	460	500	568	570	595	639	661	706	736	774	815	829	864	885	895	927	948 
];
time_points10_2_end=[460	500	568	570	595	639	661	706	736	774	815	829	864	885	895	927	948	960 
];
class10_2=[4 1 4 4 4 4 4 4 4 4 3 4 4 4 4 1 4  1 ]';
%}
%13号的步骤时间
%
time_points13_2_start = [387	408	438	477	483	504	546	570	602	613	637	653	658	670	678	689	711	733 
];
time_points13_2_end=[408	438	477	483	504	546	570	602	613	637	653	658	670	678	689	711	733	746 
];
class13_2=[3 3 3 1 3 1 1 2 2 2 2 2 1 3 1 1 1 2 ]';
%}
%14号的步骤时间
%
time_points14_2_start = [340	353	400	421	430	451	494	516	541	564	588	606	615	648	658	670	700	731 
];
time_points14_2_end=[353	400	421	430	451	494	516	541	564	588	606	615	648	658	670	700	731	743 
];
class14_2=[3 1 4 2 3 1 2 2 3 4 4 3 3 2 3 2 2 2 ]';
%}
%15号的步骤时间
%

time_points15_2_start = [409	425	466	473	517	549	567	591	602	613	625	631	647	657	671	705	770	786
];
time_points15_2_end=[425	466	473	517	549	567	591	602	613	625	631	647	657	671	705	770	786	811
];
class15_2=[2 2 2 2 2 3 2 3 4 3 4 4 4 3 4 4 4 3 ]';
%}
%% 2hao
rawdata2_2=txP1_2_2(:,13);
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata2_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points2_2_start,time_points2_2_end,class2_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points2_2_start,time_points2_2_end,class2_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points2_2_start,time_points2_2_end,class2_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points2_2_start,time_points2_2_end,class2_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points2_2_start,time_points2_2_end,class2_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points2_2_start,time_points2_2_end,class2_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points2_2_start,time_points2_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_2hao=feature_all2;
%% 3hao
rawdata3_2=txP1_3_2(:,13);
% [Delta1,Theta1,Alpha1,Beta1,Gamma1,rawdata_yuchuli1,t1]= EEG_Get_yuchuli(rawdata3_1);
% feature1_1 = EEG_feature24_func(rawdata_yuchuli1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points3_1_start,time_points3_1_end,class3_1);
% feature1_2 = EEG_feature24_func(Delta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points3_1_start,time_points3_1_end,class3_1);%为什么获得的是复数矩阵？
% feature1_3 = EEG_feature24_func(Theta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points3_1_start,time_points3_1_end,class3_1);
% feature1_4 = EEG_feature24_func(Alpha1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points3_1_start,time_points3_1_end,class3_1);
% feature1_5 = EEG_feature24_func(Beta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points3_1_start,time_points3_1_end,class3_1);
% feature1_6 = EEG_feature24_func(Gamma1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points3_1_start,time_points3_1_end,class3_1);
% feature1_7=EEG_avg_power_func(rawdata_yuchuli1,time_points3_1_start,time_points3_1_end);
% C1 = horzcat(feature1_2(:,1:end-6),feature1_3(:,2:end-6),feature1_4(:,2:end-6),feature1_5(:,2:end-6),feature1_6(:,2:end-6),feature1_7,feature1_1(:,2:end));%横向合并
% feature_all1=real(C1);
% C = vertcat(feature1, feature2);%纵向合并
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata3_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points3_2_start,time_points3_2_end,class3_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points3_2_start,time_points3_2_end,class3_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points3_2_start,time_points3_2_end,class3_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points3_2_start,time_points3_2_end,class3_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points3_2_start,time_points3_2_end,class3_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points3_2_start,time_points3_2_end,class3_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points3_2_start,time_points3_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_3hao=feature_all2;
%% 4hao
% rawdata4_1=txP1_4_1(:,13);
rawdata4_2=txP1_4_2(:,13);
% [Delta1,Theta1,Alpha1,Beta1,Gamma1,rawdata_yuchuli1,t1]= EEG_Get_yuchuli(rawdata4_1);
% feature1_1 = EEG_feature24_func(rawdata_yuchuli1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points4_1_start,time_points4_1_end,class4_1);
% feature1_2 = EEG_feature24_func(Delta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points4_1_start,time_points4_1_end,class4_1);%为什么获得的是复数矩阵？
% feature1_3 = EEG_feature24_func(Theta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points4_1_start,time_points4_1_end,class4_1);
% feature1_4 = EEG_feature24_func(Alpha1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points4_1_start,time_points4_1_end,class4_1);
% feature1_5 = EEG_feature24_func(Beta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points4_1_start,time_points4_1_end,class4_1);
% feature1_6 = EEG_feature24_func(Gamma1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points4_1_start,time_points4_1_end,class4_1);
% feature1_7=EEG_avg_power_func(rawdata_yuchuli1,time_points4_1_start,time_points4_1_end);
% C1 = horzcat(feature1_2(:,1:end-6),feature1_3(:,2:end-6),feature1_4(:,2:end-6),feature1_5(:,2:end-6),feature1_6(:,2:end-6),feature1_7,feature1_1(:,2:end));%横向合并
% feature_all1=real(C1);
% C = vertcat(feature1, feature2);%纵向合并
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata4_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points4_2_start,time_points4_2_end,class4_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points4_2_start,time_points4_2_end,class4_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points4_2_start,time_points4_2_end,class4_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points4_2_start,time_points4_2_end,class4_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points4_2_start,time_points4_2_end,class4_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points4_2_start,time_points4_2_end,class4_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points4_2_start,time_points4_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_4hao=feature_all2;
%% 5hao
% rawdata5_1=txP1_5_1(:,13);
rawdata5_2=txP1_5_2(:,13);
% [Delta1,Theta1,Alpha1,Beta1,Gamma1,rawdata_yuchuli1,t1]= EEG_Get_yuchuli(rawdata5_1);
% feature1_1 = EEG_feature24_func(rawdata_yuchuli1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points5_1_start,time_points5_1_end,class5_1);
% feature1_2 = EEG_feature24_func(Delta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points5_1_start,time_points5_1_end,class5_1);%为什么获得的是复数矩阵？
% feature1_3 = EEG_feature24_func(Theta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points5_1_start,time_points5_1_end,class5_1);
% feature1_4 = EEG_feature24_func(Alpha1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points5_1_start,time_points5_1_end,class5_1);
% feature1_5 = EEG_feature24_func(Beta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points5_1_start,time_points5_1_end,class5_1);
% feature1_6 = EEG_feature24_func(Gamma1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points5_1_start,time_points5_1_end,class5_1);
% feature1_7=EEG_avg_power_func(rawdata_yuchuli1,time_points5_1_start,time_points5_1_end);
% C1 = horzcat(feature1_2(:,1:end-6),feature1_3(:,2:end-6),feature1_4(:,2:end-6),feature1_5(:,2:end-6),feature1_6(:,2:end-6),feature1_7,feature1_1(:,2:end));%横向合并
% feature_all1=real(C1);
% C = vertcat(feature1, feature2);%纵向合并
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata5_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points5_2_start,time_points5_2_end,class5_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points5_2_start,time_points5_2_end,class5_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points5_2_start,time_points5_2_end,class5_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points5_2_start,time_points5_2_end,class5_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points5_2_start,time_points5_2_end,class5_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points5_2_start,time_points5_2_end,class5_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points5_2_start,time_points5_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_5hao=feature_all2;
%% 6hao
% rawdata6_1=txP1_6_1(:,13);
rawdata6_2=txP1_6_2(:,13);
% [Delta1,Theta1,Alpha1,Beta1,Gamma1,rawdata_yuchuli1,t1]= EEG_Get_yuchuli(rawdata6_1);
% feature1_1 = EEG_feature24_func(rawdata_yuchuli1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points6_1_start,time_points6_1_end,class6_1);
% feature1_2 = EEG_feature24_func(Delta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points6_1_start,time_points6_1_end,class6_1);%为什么获得的是复数矩阵？
% feature1_3 = EEG_feature24_func(Theta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points6_1_start,time_points6_1_end,class6_1);
% feature1_4 = EEG_feature24_func(Alpha1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points6_1_start,time_points6_1_end,class6_1);
% feature1_5 = EEG_feature24_func(Beta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points6_1_start,time_points6_1_end,class6_1);
% feature1_6 = EEG_feature24_func(Gamma1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points6_1_start,time_points6_1_end,class6_1);
% feature1_7=EEG_avg_power_func(rawdata_yuchuli1,time_points6_1_start,time_points6_1_end);
% C1 = horzcat(feature1_2(:,1:end-6),feature1_3(:,2:end-6),feature1_4(:,2:end-6),feature1_5(:,2:end-6),feature1_6(:,2:end-6),feature1_7,feature1_1(:,2:end));%横向合并
% feature_all1=real(C1);
% C = vertcat(feature1, feature2);%纵向合并
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata6_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points6_2_start,time_points6_2_end,class6_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points6_2_start,time_points6_2_end,class6_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points6_2_start,time_points6_2_end,class6_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points6_2_start,time_points6_2_end,class6_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points6_2_start,time_points6_2_end,class6_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points6_2_start,time_points6_2_end,class6_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points6_2_start,time_points6_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_6hao=feature_all2;
%% 7hao
% rawdata7_1=txP1_7_1(:,13);
rawdata7_2=txP1_7_2(:,13);
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata7_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points7_2_start,time_points7_2_end,class7_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points7_2_start,time_points7_2_end,class7_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points7_2_start,time_points7_2_end,class7_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points7_2_start,time_points7_2_end,class7_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points7_2_start,time_points7_2_end,class7_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points7_2_start,time_points7_2_end,class7_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points7_2_start,time_points7_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_7hao=feature_all2;
%% 8hao
rawdata8_2=txP1_8_2(:,13);
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata8_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points8_2_start,time_points8_2_end,class8_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points8_2_start,time_points8_2_end,class8_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points8_2_start,time_points8_2_end,class8_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points8_2_start,time_points8_2_end,class8_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points8_2_start,time_points8_2_end,class8_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points8_2_start,time_points8_2_end,class8_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points8_2_start,time_points8_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_8hao=feature_all2;
%% 9hao
rawdata9_2=txP1_9_2(:,13);
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata9_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points9_2_start,time_points9_2_end,class9_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points9_2_start,time_points9_2_end,class9_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points9_2_start,time_points9_2_end,class9_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points9_2_start,time_points9_2_end,class9_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points9_2_start,time_points9_2_end,class9_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points9_2_start,time_points9_2_end,class9_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points9_2_start,time_points9_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_9hao=vertcat(feature_all2);

%% 10hao
% rawdata10_1=txP1_10_1(:,13);
rawdata10_2=txP1_10_2(:,13);
% [Delta1,Theta1,Alpha1,Beta1,Gamma1,rawdata_yuchuli1,t1]= EEG_Get_yuchuli(rawdata10_1);
% feature1_1 = EEG_feature24_func(rawdata_yuchuli1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points10_1_start,time_points10_1_end,class10_1);
% feature1_2 = EEG_feature24_func(Delta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points10_1_start,time_points10_1_end,class10_1);%为什么获得的是复数矩阵？
% feature1_3 = EEG_feature24_func(Theta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points10_1_start,time_points10_1_end,class10_1);
% feature1_4 = EEG_feature24_func(Alpha1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points10_1_start,time_points10_1_end,class10_1);
% feature1_5 = EEG_feature24_func(Beta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points10_1_start,time_points10_1_end,class10_1);
% feature1_6 = EEG_feature24_func(Gamma1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points10_1_start,time_points10_1_end,class10_1);
% feature1_7=EEG_avg_power_func(rawdata_yuchuli1,time_points10_1_start,time_points10_1_end);
% C1 = horzcat(feature1_2(:,1:end-6),feature1_3(:,2:end-6),feature1_4(:,2:end-6),feature1_5(:,2:end-6),feature1_6(:,2:end-6),feature1_7,feature1_1(:,2:end));%横向合并
% feature_all1=real(C1);
% C = vertcat(feature1, feature2);%纵向合并
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata10_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points10_2_start,time_points10_2_end,class10_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points10_2_start,time_points10_2_end,class10_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points10_2_start,time_points10_2_end,class10_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points10_2_start,time_points10_2_end,class10_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points10_2_start,time_points10_2_end,class10_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points10_2_start,time_points10_2_end,class10_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points10_2_start,time_points10_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_10hao=feature_all2;
%% 13hao
rawdata13_2=txP1_13_2(:,13);
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata13_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points13_2_start,time_points13_2_end,class13_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points13_2_start,time_points13_2_end,class13_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points13_2_start,time_points13_2_end,class13_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points13_2_start,time_points13_2_end,class13_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points13_2_start,time_points13_2_end,class13_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points13_2_start,time_points13_2_end,class13_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points13_2_start,time_points13_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_13hao=feature_all2;

%% 14hao
% rawdata14_1=txP1_8_1(:,13);
rawdata14_2=txP1_14_2(:,13);
% [Delta1,Theta1,Alpha1,Beta1,Gamma1,rawdata_yuchuli1,t1]= EEG_Get_yuchuli(rawdata14_1);
% feature1_1 = EEG_feature24_func(rawdata_yuchuli1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points14_1_start,time_points14_1_end,class14_1);
% feature1_2 = EEG_feature24_func(Delta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points14_1_start,time_points14_1_end,class14_1);%为什么获得的是复数矩阵？
% feature1_3 = EEG_feature24_func(Theta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points14_1_start,time_points14_1_end,class14_1);
% feature1_4 = EEG_feature24_func(Alpha1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points14_1_start,time_points14_1_end,class14_1);
% feature1_5 = EEG_feature24_func(Beta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points14_1_start,time_points14_1_end,class14_1);
% feature1_6 = EEG_feature24_func(Gamma1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points14_1_start,time_points14_1_end,class14_1);
% feature1_7=EEG_avg_power_func(rawdata_yuchuli1,time_points14_1_start,time_points14_1_end);
% C1 = horzcat(feature1_2(:,1:end-6),feature1_3(:,2:end-6),feature1_4(:,2:end-6),feature1_5(:,2:end-6),feature1_6(:,2:end-6),feature1_7,feature1_1(:,2:end));%横向合并
% feature_all1=real(C1);
% C = vertcat(feature1, feature2);%纵向合并
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata14_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points14_2_start,time_points14_2_end,class14_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points14_2_start,time_points14_2_end,class14_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points14_2_start,time_points14_2_end,class14_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points14_2_start,time_points14_2_end,class14_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points14_2_start,time_points14_2_end,class14_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points14_2_start,time_points14_2_end,class14_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points14_2_start,time_points14_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_14hao=feature_all2;
%% 15hao
% rawdata15_1=txP1_15_1(:,13);
rawdata15_2=txP1_15_2(:,13);
% [Delta1,Theta1,Alpha1,Beta1,Gamma1,rawdata_yuchuli1,t1]= EEG_Get_yuchuli(rawdata15_1);
% feature1_1 = EEG_feature24_func(rawdata_yuchuli1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points15_1_start,time_points15_1_end,class15_1);
% feature1_2 = EEG_feature24_func(Delta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points15_1_start,time_points15_1_end,class15_1);%为什么获得的是复数矩阵？
% feature1_3 = EEG_feature24_func(Theta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points15_1_start,time_points15_1_end,class15_1);
% feature1_4 = EEG_feature24_func(Alpha1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points15_1_start,time_points15_1_end,class15_1);
% feature1_5 = EEG_feature24_func(Beta1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points15_1_start,time_points15_1_end,class15_1);
% feature1_6 = EEG_feature24_func(Gamma1,Delta1,Theta1,Alpha1,Beta1,Gamma1,time_points15_1_start,time_points15_1_end,class15_1);
% feature1_7=EEG_avg_power_func(rawdata_yuchuli1,time_points15_1_start,time_points15_1_end);
% C1 = horzcat(feature1_2(:,1:end-6),feature1_3(:,2:end-6),feature1_4(:,2:end-6),feature1_5(:,2:end-6),feature1_6(:,2:end-6),feature1_7,feature1_1(:,2:end));%横向合并
% feature_all1=real(C1);
% C = vertcat(feature1, feature2);%纵向合并
%%通过调用函数获得feature矩阵,下面是实验二六种波形分别获得的特征最后汇总在feature——all1中；
[Delta2,Theta2,Alpha2,Beta2,Gamma2,rawdata_yuchuli2,t2]= EEG_Get_yuchuli(rawdata15_2);
feature2_1 = EEG_feature24_func(rawdata_yuchuli2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points15_2_start,time_points15_2_end,class15_2);
feature2_2 = EEG_feature24_func(Delta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points15_2_start,time_points15_2_end,class15_2);%为什么获得的是复数矩阵？
feature2_3 = EEG_feature24_func(Theta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points15_2_start,time_points15_2_end,class15_2);
feature2_4 = EEG_feature24_func(Alpha2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points15_2_start,time_points15_2_end,class15_2);
feature2_5 = EEG_feature24_func(Beta2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points15_2_start,time_points15_2_end,class15_2);
feature2_6 = EEG_feature24_func(Gamma2,Delta2,Theta2,Alpha2,Beta2,Gamma2,time_points15_2_start,time_points15_2_end,class15_2);
feature2_7=EEG_avg_power_func(rawdata_yuchuli2,time_points15_2_start,time_points15_2_end);
C2 = horzcat(feature2_2(:,1:end-6),feature2_3(:,2:end-6),feature2_4(:,2:end-6),feature2_5(:,2:end-6),feature2_6(:,2:end-6),feature2_7,feature2_1(:,2:end));%横向合并
feature_all2=real(C2);
feature_all_15hao=feature_all2;


data=vertcat(feature_all_2hao,feature_all_3hao,feature_all_4hao,feature_all_5hao,feature_all_6hao,feature_all_7hao,feature_all_8hao,feature_all_9hao,feature_all_10hao,feature_all_13hao,feature_all_14hao,feature_all_15hao);
% 检查数据是否包含 NaN 或 inf 数据点
has_nan = any(isnan(data(:))); % 是否存在 NaN
has_inf = any(isinf(data(:))); % 是否存在 inf

% 如果数据包含 NaN 或 inf 数据点，则删除包含这些数据点的列
if has_nan || has_inf
    % 找到包含 NaN 或 inf 数据点的列
    nan_cols = any(isnan(data), 1); % 包含 NaN 数据点的列
    inf_cols = any(isinf(data), 1); % 包含 inf 数据点的列
    % 删除这些列
    data(:, nan_cols | inf_cols) = [];
end
%% 进行特征归一化消除个体差异

% 对数据集第2~4列进行归一化处理
data_normalized = data;
data_normalized(:,2:end-1) = normalize(data(:,2:end-1));

feature_all_ALLhao=data_normalized;

