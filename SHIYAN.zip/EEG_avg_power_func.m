function [feature_all] = EEG_avg_power_func(eeg_data,start_times,end_times)
%eeg_data:输入的信号，start_times,end_times：起始时间点和终止时间点,本程序用来实现计算EEG的节律波平均功率密度
%num：两个实验的序号,其数量应该与时间段个数一样
sampling_rate = 512; % 假设采样率为512Hz 
% eeg_data=rawdata1;
for i = 1:length(start_times)
    % 获取对应时间点的数据样本
    start_sample = start_times(i) * sampling_rate + 1;
    end_sample = end_times(i) * sampling_rate + 1;
    data = eeg_data(start_sample:end_sample);

     N = length(data);

% 加载脑电信号数据(假设数据为一列向量)

% 用pwelch函数进行功率谱密度分析
[Pxx, freqs] = pwelch(data,[],[],[],sampling_rate);
% plot(freqs,Pxx,'b','linewidth',2)
% xlabel('Frequency (Hz)'); ylabel('Power (dB)')
% f_lim = freqs((freqs>0)&(freqs<=100));
% set(gca,'xlim',[min(f_lim),max(f_lim)])
% 计算节律波频率带的平均功率谱密度
delta_freq_range = freqs >= 0.5 & freqs < 4; % delta波频率带范围
theta_freq_range = freqs >= 4 & freqs < 8;  % theta波频率带范围
alpha_freq_range = freqs >= 8 & freqs < 13; % alpha波频率带范围
beta_freq_range = freqs >= 13 & freqs < 30; % beta波频率带范围
gamma_freq_range = freqs >= 30 & freqs < 100; % gamma波频率带范围

% 计算各波段的平均功率谱密度
delta_avg_power = mean(Pxx(delta_freq_range));
theta_avg_power = mean(Pxx(theta_freq_range));
alpha_avg_power = mean(Pxx(alpha_freq_range));
beta_avg_power = mean(Pxx(beta_freq_range));
gamma_avg_power = mean(Pxx(gamma_freq_range));
features(i, :) = [delta_avg_power,theta_avg_power,alpha_avg_power,beta_avg_power,gamma_avg_power];

end
feature_all=features;
end