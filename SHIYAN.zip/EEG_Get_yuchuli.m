function  [Delta,Theta,Alpha,Beta,Gamma,filtered_data2,t]= EEG_Get_yuchuli(data)
%% data:输入的信号,输出为五种节律波和预处理后的信号
%% 程序中包含对脑电原始信号的预处理步骤：
%% 1.阈值法去除噪点，将大于327和小于-327的点使用转化为附近的500个点的均值。
%% 2.带通滤波0.1-150hz，将阈值法处理后的信号进行巴特沃斯带通滤波，使信号更加平滑，便于后面处理
%% 3.小波包分解重构，将带通滤波后的信号进行db4的6层小波包分解，获得0-4，4-8，8-12，12-20，20-32hz的五种节律波
%% 阈值法去除噪点
% 读取数据
fs = 512;
% 定义阈值范围
threshold_high = 327;    % 上限阈值
threshold_low = -327;    % 下限阈值
% 定义附近的数据点数量
neighbor = 500;          % 附近数据点的数量
% 获取数据长度
n = length(data);
% 定义用于存储处理后数据的向量
filtered_data = zeros(n, 1);
% 遍历每个数据点
for i = 1:n
    % 判断是否超出阈值范围
    if data(i) > threshold_high || data(i) < threshold_low
        % 确定附近数据点的索引
        index = max(i-neighbor, 1):min(i+neighbor, n);
        % 计算附近数据点的平均值
        mean_value = mean(data(index));
        % 将当前数据点替换为平均值
        filtered_data(i) = mean_value;
    else
        % 如果不超出阈值范围，则不进行替换
        filtered_data(i) = data(i);
    end
end
% 计算需要替换的噪点所占的比例
% num_noise = sum((filtered_data > threshold_high) | (filtered_data < threshold_low));
% percent_noise = num_noise / n * 100;
% 显示去噪后数据

t = ((0:length(data)-1)/fs)'; % 时间轴
%{
figure;
plot(t, data, 'b', t, filtered_data, 'r');
title('平均值阈值去噪后的数据');
xlabel('时间 (s)');
ylabel('信号强度');
legend('原始数据', '去噪后数据');
%}
% 计算所占总数据量的百分比
lower_count = sum(data < -327);
upper_count = sum(data > 327);
total_count = length(data);
lower_percent = 100 * lower_count / total_count;
upper_percent = 100 * upper_count / total_count;
% 输出结果
fprintf('小于-327的数据点数量：%d，占总数据量的%.2f%%\n', lower_count, lower_percent);
fprintf('大于327的数据点数量：%d，占总数据量的%.2f%%\n', upper_count, upper_percent);


%% 带通滤波0.5-85hz
% 定义滤波器参数
          % 采样率
          %
f1 = 0.1;          % 通带下限频率
f2 = 150;           % 通带上限频率
Wp = [f1, f2]/(fs/2); % 通带截止频率
Rp = 0.5;            % 通带最大衰减量，单位dB
Rs = 30;           % 阻带最小衰减量，单位dB
[n, Wn] = buttord(Wp(1), Wp(2), Rp, Rs); % 计算巴特沃斯滤波器阶数和截止频率
[b, a] = butter(n, Wn); % 计算滤波器系数

% 应用滤波器
filtered_data2 = filter(b, a, filtered_data);

% 显示滤波效果
%{

% figure;
% plot(t, filtered_data, 'b', t, filtered_data2, 'r');
% title('带通滤波器滤波效果');
% xlabel('时间 (s)');
% ylabel('信号强度');
% legend('原始数据', '滤波后数据');
%}
          %}
%% 进行6层db4小波包分解重构
x_input=filtered_data2;           %输入数据
% plot(x_input);title('输入信号时域图像')  %绘制输入信号时域图像
 
x=x_input;        %   查看频谱范围
N=length(x); %采样点个数
signalFFT=abs(fft(x,N));%真实的幅值
Y=2*signalFFT/N;
f=(0:N/2)*(fs/N);
% figure;plot(f,Y(1:N/2+1));
% ylabel('amp'); xlabel('frequency');title('输入信号的频谱');grid on
wpt=wpdec(x_input,6,'db4');      %进行6层小波包分解
% plot(wpt);                        %绘制小波包树
 
%% 实现对节点顺序按照频率递增进行重排序
% nodes=get(wpt,'tn');  %小波包分解系数　为什么ｎｏｄｅｓ是[7;8;9;10;11;12;13;14]
% N_cfs=length(nodes);  %小波包系数个数
nodes=[63:126]';
ord=wpfrqord(nodes);  %小波包系数重排，ord是重排后小波包系数索引构成的矩阵　如3层分解的[1;2;4;3;7;8;6;5]
nodes_ord=nodes(ord); %重排后的小波系数
 
%% 实现对节点小波节点进行重构 
for i=1:64
rex3(:,i)=wprcoef(wpt,nodes_ord(i));         
end
 %%  最终获得的几种节律波
%  Delta=rex3(:,1);%0-4hz
% Theta=rex3(:,2);%4-8hz
% Alpha=rex3(:,3);%8-12hz
% Beta=rex3(:,4)+rex3(:,5);%12-20hz
% Gamma=rex3(:,6)+rex3(:,7)+rex3(:,8);%20-32hz
%
Delta=abs(rex3(:,1));%0-4hz
Theta=abs(rex3(:,2));%4-8hz
Alpha=abs(rex3(:,3));%8-12hz
Beta=abs(rex3(:,4)+rex3(:,5));%12-20hz
Gamma=abs(rex3(:,6)+rex3(:,7)+rex3(:,8));%20-32hz
%}
% t = linspace(0, length(Delta)/fs, length(Delta))';  % 计算时间轴数据
%% 节律波作图
%{
subplot(6,1,1);
plot(t, Delta);  % 绘制波形图
xlabel('Time (s)');  % 设置横轴标签为时间
ylabel('Delta');  % 设置纵轴标签为幅值
title('EEG Delta');  % 设置图标题
subplot(6,1,2);
plot(t, Theta);  % 绘制波形图
xlabel('Time (s)');  % 设置横轴标签为时间
ylabel('Theta');  % 设置纵轴标签为幅值
title('EEG Theta');  % 设置图标题
subplot(6,1,3);
plot(t, Alpha);  % 绘制波形图
xlabel('Time (s)');  % 设置横轴标签为时间
ylabel('Alpha');  % 设置纵轴标签为幅值
title('EEG Alpha');  % 设置图标题
subplot(6,1,4);
plot(t, Beta);  % 绘制波形图
xlabel('Time (s)');  % 设置横轴标签为时间
ylabel('Beta');  % 设置纵轴标签为幅值
title('EEG Beta');  % 设置图标题
subplot(6,1,5);
plot(t, Gamma);  % 绘制波形图
xlabel('Time (s)');  % 设置横轴标签为时间
ylabel('Gamma');  % 设置纵轴标签为幅值
title('EEG Gamma');  % 设置图标题
subplot(6,1,6);
plot(t, filtered_data2);  % 绘制波形图
xlabel('Time (s)');  % 设置横轴标签为时间
ylabel('filtered_data2');  % 设置纵轴标签为幅值
title('filtered_data2');  % 设置图标题
 %}




end